public class Contador {

    public static int contarValoresEntre(int primeiro, int N, int[] dados) {
        int contador = 0;

        for (int i = 0; i < dados.length; i++) {
            if (dados[i] >= primeiro && dados[i] <= N) {
                contador++;
            }
        }

        return contador;
    }

    public static void main(String[] args) {
        // Exemplo de uso:
        int[] dados = {1, 3, 5, 7, 8, 10, 12, 15};
        int primeiro = 3;
        int N = 10;

        System.out.println(contarValoresEntre(primeiro, N, dados));
    }
}
